import React, { useState } from "react";
import reactLogo from "./assets/react.svg";
import viteLogo from "/vite.svg";
import "./App.css";
import Footer from "./components/Footer";
import Header from "./components/Header";
import ScrollMenu from "./components/ScrollMenu";
import Hondo from "./components/shared/Hondo";
import Reel from "./components/sections/Reel";
import Video from "./components/sections/Video";
import Portfolio from "./components/sections/Portfolio";
import Equipo from "./components/sections/Equipo";
import Contact from "./components/sections/Contact";
import Diseno from "./components/sections/Diseno";
import Paellas from "./components/sections/Paellas";
import Foto from "./components/sections/Foto";
function App() {
  const [count, setCount] = useState(0);
  console.log(count);
  return (
    <div className='h-full relative '>
      {/* <div className='relative w-screen'>
        <span className='fixed text-6xl top-10 right-10 text-white'>Honda</span>
        <ScrollMenu />
      </div> */}
      <span className='top-10 right-10 text-white  z-[30] text-[4rem] fixed '>
        {" "}
        Hondo
      </span>

      <Header />

      <div className='relative h-full !z-1'>
        <ScrollMenu count={count} setCount={setCount} />

        <Reel count={count} />
        <Video count={count} />
        <Foto count={count} />
        <Diseno count={count} />
        <Portfolio count={count} />
        <Equipo count={count} />
        <Paellas count={count} />
        <Contact count={count} />
        {/* 
        
        */}
      </div>

      {/* <Hondo /> */}
      <div className='text-violet-700 text-start p-5 z-20 relative bg-white  flex flex-col justify-end text-[2rem] leading-[50px] '>
        +34662122660 <br /> Carrer de l’Esglesia 4-6, Barcelona.
        <br />
        hola@hondostudio.com
      </div>
      <Footer />
    </div>
  );
}

export default App;
